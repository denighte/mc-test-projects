package ru.magistu.siegemachines.entity.projectile;

public enum FlightType
{
    NONE,
    AHEAD,
    SPINNING
}
